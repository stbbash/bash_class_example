from .module1 import FindMaxAndMin, FirstNonConsecutive, FindShortString, Strlen
